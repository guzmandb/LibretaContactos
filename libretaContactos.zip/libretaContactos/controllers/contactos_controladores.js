const cargarApp = async(req,res) => {

    res.render('libreta', {title: 'Libreta'});

}

const cargarContactos = async(req,res) => {

    const contactos =[

        {
        "nombre": "Camila Peña",
        "telefono": "3013334452",
        "correo": "camipeña@hotmail.com"
        },

        {
        "nombre": "Isabella Martinez",
        "telefono": "3135332179",
        "correo": "isamart@gmail.com"
        },

        {"nombre": "Miguel Villa",
        "telefono": "3125500212",
        "correo": "mikeville@outlook.com"
        }
    ];


    res.send(contactos);

}


module.exports = { cargarApp, cargarContactos }