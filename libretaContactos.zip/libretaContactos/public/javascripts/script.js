let contactos = [];

$(document).ready(function(){
    
    cargarContactos();

    let formulario = $('.formularioAgregar');

    $('.button').on('click',function(){
        let formulario = $(this).parent().parent();
        incluirContacto(formulario.find('#txt_nombre').val(), formulario.find('#txt_telefono').val(),formulario.find('#txt_correo').val());
        
    });

    function cambiarColorTarjeta(){
        $('.card').removeClass('text-white bg-danger');//row
        $(this).addClass('text-white bg-danger');
    }


    function mostrarDatos(){
        $(this).find('.oculto').fadeToggle();
    }

    function cargarContactos(){
       
        $.get('/contactos/cargarInfo',function(data) {
            for(let i=0; i<data.length; i++){
                incluirContacto(data[i].nombre, data[i].telefono, data[i].correo);
            }
        });
    }

    function incluirContacto(nombre, telefono, correo){

        const contacto = new Contacto (nombre, telefono, correo);
        contactos.push(contacto);

        let row = $('<div class ="row"></div>'); //div
        row.prepend('<div class ="col-12"></div>');
        row.find('.col-12').prepend('<div class ="card mb-3"></div>');
        row.find('.card').prepend('<div class ="row no-gutters"></div>');
        row.find('.row').prepend('<div class ="col-md-4"></div>');
        row.find('.col-md-4').prepend('<img src="/images/icono-de-telefono.png" class="card-img">');
        row.find('.row').append('<div class ="col-md-8"></div>');
        row.find('.col-md-8').prepend('<div class ="card-body"></div>');
        row.find('.card-body').append('<h5 class="card-title">' +  contacto.nombre + '</h5>');
        row.find('.card-body').append('<div class="oculto"></div>');
        row.find('.card-body').find('.oculto').append('<p class ="card-text">'+ contacto.telefono +'</p>');
        row.find('.card-body').find('.oculto').append('<p class ="card-text">'+ contacto.correo +'</p>');
        row.find('.card').on("click", cambiarColorTarjeta);
        row.find('.card').on("click", mostrarDatos);
        $('#listaContactos').find('h2').after(row);
 
    }
});

    class Contacto{
        constructor(nombre,telefono,correo){
            this.nombre = nombre;
            this.telefono = telefono;
            this.correo = correo;
        }
    }



