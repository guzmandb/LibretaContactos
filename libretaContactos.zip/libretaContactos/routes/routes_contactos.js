var express = require('express');
var router = express.Router();
const contactosController = require('../controllers/contactos_controladores.js');

router.get('/',contactosController.cargarApp);
router.get('/cargarInfo',contactosController.cargarContactos);


module.exports = router;

